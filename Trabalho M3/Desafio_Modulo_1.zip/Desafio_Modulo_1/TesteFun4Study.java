import java.io.*;
/**
 * Classe de TesteFun4Study efetida na prática a realização do cadastro.
 * Evandro Silveira da Motta) 
 *
 * @version (29/04/2020
 */
public class TesteFun4Study{
    public static void main(String args[]){
        
        
        System.out.println("**Bem vindo ao Cadastro estudantil da Fu4nStudy.**");
        System.out.println(" ");
        //Cadastro cidade 1
        System.out.println("\nCadastre a Cidade 1:\n");
        Cidade novaCidade1 = new Cidade(Teclado.leInt("Informe o código da Cidade: "),
        Teclado.leString("Informe a Cidade: "),
        Teclado.leString("Informe a UF: "));

        System.out.println("\nCadastre o Estudante 1:\n ");
        
        Estudantes novoAluno1 = new Estudantes(Teclado.leInt("Informe o código do Estudante: "),
        Teclado.leString("Informe o nome: "),
        Teclado.leString("Informe a data de nascimento: "),
        Teclado.leString("Informe o e-mail: "),
        Teclado.leString("Informe a senha: "),
        novaCidade1);  
        
        //Atualização da senha Aluno 1
        String senhaAnterior;
        String novaSenha;
        String confirmaSenha;
        System.out.println("\n" + novoAluno1.getNome() + " Atualize sua senha! ");
        senhaAnterior = Teclado.leString("Digite sua Senha Anterior: ");
        novaSenha = Teclado.leString("Digite sua Nova Senha: ");
        confirmaSenha = Teclado.leString("Confirme sua Nova Senha: ");

        if(novoAluno1.getSenha().equals(senhaAnterior) && novaSenha.equals(confirmaSenha)){
        novoAluno1.setSenha(confirmaSenha);
        System.out.println("\n***Sua Senha foi atualizada com sucesso***!");
        }else{
            System.out.println("\n***ERRO: AS SENHAS NÃO CONFEREM!***");
        }
        
        //Cadastro Aluno 2
        System.out.println("\nCadastre o Estudante 2:\n ");
        
        Estudantes novoAluno2 = new Estudantes(Teclado.leInt("Informe o código do Estudante: "),
        Teclado.leString("Informe o nome: "),
        Teclado.leString("Informe a data de nascimento: "),
        Teclado.leString("Informe o e-mail: "),
        Teclado.leString("Informe a senha: "),
        novaCidade1); 
        
        //Atualização da senha Aluno 2
        System.out.println("\n" + novoAluno2.getNome() + " Atualize sua senha! ");
        senhaAnterior = Teclado.leString("Digite a sua Senha Anterior: ");
        novaSenha = Teclado.leString("Digite sua Nova Senha: ");
        confirmaSenha = Teclado.leString("Confirme sua Nova Senha: ");

        if(novoAluno2.getSenha().equals(senhaAnterior) && novaSenha.equals(confirmaSenha)){
        novoAluno2.setSenha(confirmaSenha);
        System.out.println("\n***Sua senha foi atualizada com sucesso!***");
        }else{
            System.out.println("\n***ERRO: AS SENHAS NÃO CONFEREM!***");
        }
        
        System.out.println(" ");
        
        novaCidade1.exibeDados();
        novoAluno1.exibeDados();
        novoAluno2.exibeDados();
        
        //Cadastro cidade 2
        
        System.out.println("\nCadastre a Cidade 2:\n");
        Cidade novaCidade2 = new Cidade(Teclado.leInt("Informe o código da Cidade:"),
        Teclado.leString("Informe a Cidade: "),
        Teclado.leString("Informe a UF: "));
        
        //Cadastro Aluno 3
        System.out.println("\nCadastre o Estudante 3:\n ");
        
        Estudantes novoAluno3 = new Estudantes(Teclado.leInt("Informe o código do Estudante: "),
        Teclado.leString("Informe o nome: "),
        Teclado.leString("Informe a data de nascimento: "),
        Teclado.leString("Informe o e-mail: "),
        Teclado.leString("Informe a senha: "),
        novaCidade2);
        
        //Atualização da senha Aluno 3
        System.out.println("\n" + novoAluno3.getNome() + " Atualize sua senha! ");
        senhaAnterior = Teclado.leString("Digite sua Senha Anterior: ");
        novaSenha = Teclado.leString("Digite sua Nova Senha: ");
        confirmaSenha = Teclado.leString("Confirme sua Nova Senha: ");

        if(novoAluno3.getSenha().equals(senhaAnterior) && novaSenha.equals(confirmaSenha)){
        novoAluno3.setSenha(confirmaSenha);
        System.out.println("\n***Sua senha foi atualizada com sucesso!***");
        }else{
            System.out.println("\n***ERRO: AS SENHAS NÃO CONFEREM!***");
        }
        
        //Cadastro do Aluno 4
        
        System.out.println("\nCadastre o Estudante 4:\n ");
        
        Estudantes novoAluno4 = new Estudantes(Teclado.leInt("Informe o código do Estudante: "),
        Teclado.leString("Informe o nome: "),
        Teclado.leString("Informe a data de nascimento: "),
        Teclado.leString("Informe o e-mail: "),
        Teclado.leString("Informe a senha: "),
        novaCidade2);
        
        //Atualização da senha Aluno 4
        System.out.println("\n" + novoAluno4.getNome() + " Atualize sua senha! ");
        senhaAnterior = Teclado.leString("Digite a sua Senha Anterior: ");
        novaSenha = Teclado.leString("Digite sua Nova Senha: ");
        confirmaSenha = Teclado.leString("Confirme sua Nova Senha: ");

        if(novoAluno4.getSenha().equals(senhaAnterior) && novaSenha.equals(confirmaSenha)){
        novoAluno4.setSenha(confirmaSenha);
        System.out.println("\nA ***Sua senha foi atualizada com sucesso!***");
        }else{
            System.out.println("\n***ERRO: AS SENHAS NÃO CONFEREM!***");
        }
        
        
        System.out.println(" ");
        
        novaCidade2.exibeDados();
        novoAluno3.exibeDados();
        novoAluno4.exibeDados();
        
    }
}  