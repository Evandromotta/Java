public class Cliente
{
    // atributos da classe
    private String cpf;
    private String nome;
    private String endereco;

    /**
     * Construtor 
     */
    public Cliente(String cp, String no, String en)
    {
        cpf = cp;
        nome = no;
        endereco = en;
    }
}
