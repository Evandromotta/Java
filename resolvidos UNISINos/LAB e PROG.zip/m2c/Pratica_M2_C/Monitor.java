public class Monitor
{
    // atributos da classe
    private double tamanhoTela;
    
    //metodo construtor
    public Monitor(double tam)
    {
        tamanhoTela = tam;
    }

}
